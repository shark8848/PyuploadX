"""PyUploadX Python client SDK per docs_product-design.md section 17."""

from pyuploadx.client import Client, UploadClient
from pyuploadx.exceptions import (
    AuthenticationError,
    AuthorizationError,
    ChecksumMismatchError,
    DirectoryUploadError,
    LifecycleError,
    MultipartError,
    RateLimitError,
    ResumeError,
    ServerError,
    StorageUnavailableError,
    UploadClientError,
    ValidationError,
)
from pyuploadx.lifecycle import FileLifecycle

__version__ = "0.10.1"

__all__ = [
    "Client",
    "UploadClient",
    "FileLifecycle",
    "UploadClientError",
    "AuthenticationError",
    "AuthorizationError",
    "ValidationError",
    "RateLimitError",
    "ServerError",
    "StorageUnavailableError",
    "MultipartError",
    "ResumeError",
    "DirectoryUploadError",
    "LifecycleError",
    "ChecksumMismatchError",
]
